from django.urls import path

app_name = "{{ app_name }}"

urlpatterns = [
    # path("", {{ camel_case_app_name }}View.as_view(), name="index"),
]
