from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class {{ camel_case_app_name }}Config(AppConfig):
    """Default app config"""

    name = "apps.{{ app_name }}"
    verbose_name = _("{{ camel_case_app_name }}")

    def ready(self):
        from . import signals  # noqa: F401 # pylint: disable=unused-import
